# Briefly summarize the requirements and goals of the app you developed. What user needs was this app designed to address?

I was tasked with creating an Inventory Application in Android Studio. The app's requirements included allowing a user to create, account and log in and being able to add, edit, and delete items from their inventory. Lastly, give the user an option to sign up for SMS notifications of low inventory. 

# What screens and features were necessary to support user needs and produce a user-centered UI for the app? How did your UI designs keep users in mind? Why were your designs successful? 

The necessary screens were the login, register, inventory screen, and add/edit screen. Using features Gridviews for easy visualization of the items as well as adding buttons to enhance the user experience. My UI design offered a simplistic approach to allow keep the user in mind. This allows for easy navigation within the app. 

# How did you approach the process of coding your app? What techniques or strategies did you use? How could those be applied in the future? 

When approaching coding of my app, I made sure to ensure that each feature was functional. Especially utilizing SQLite for storage and management as well as SMS in Android Studio. Applying what I have learned throughout this process will benefit how I approach coding. Taking my time to ensure functionality for each feature I will work with. 

# How did you test to ensure your code was functional? Why is this process important and what did it reveal? 

The way I tested to make sure my code was functioning was through Android Studios emulators. This process was important because it revealed different ways my code was behaving.  

# Considering the full app design and development process, from initial planning to finalization, where did you have to innovate to overcome a challenge? 

During the procces of coding adding an item to the inventory I ran into a challenge. For example, I would add an item to the inventory with a set quantity. I was able to then change the quantity to 0 and it worked fine. But if I added a new item with the initial quantity set to 0 my app would crash. I was able to do some research on stackoverflow to get an idea on the issue. 

# In what specific component from your mobile app were you particularly successful in demonstrating your knowledge, skills, and experience? 

Even though I ran into a problem with my app crashing. I am particularly proud of the app's fluidity. From logging in, adding, editing, and deleting an item to enabling/disabling SMS notifications.  
