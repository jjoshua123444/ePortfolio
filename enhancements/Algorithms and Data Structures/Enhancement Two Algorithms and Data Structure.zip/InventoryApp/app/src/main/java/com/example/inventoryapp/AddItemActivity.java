/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Allows users to add new items to their inventory.
 */

package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    // Indicates whether the activity is in edit mode
    private boolean editMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize UI components
        EditText editTextItemName = findViewById(R.id.editTextItemName);
        EditText editTextQuantity = findViewById(R.id.editTextQuantity);
        Button buttonSaveItem = findViewById(R.id.buttonAdd);
        Button buttonBack = findViewById(R.id.buttonBack);

        // Check if the activity is in edit mode
        Intent intent = getIntent();
        if (intent.hasExtra("edit_mode")) {
            editMode = intent.getBooleanExtra("edit_mode", false);
            // pre-fill the fields with existing item details
            if (editMode) {
                String itemName = intent.getStringExtra("item_name");
                int quantity = intent.getIntExtra("quantity", 0);
                editTextItemName.setText(itemName);
                editTextQuantity.setText(String.valueOf(quantity));
            }
        }

        // Set onClick listener for the Save button
        buttonSaveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the item details
                String itemName = editTextItemName.getText().toString();
                int quantity = Integer.parseInt(editTextQuantity.getText().toString());

                // Check if the item name is not empty
                if (!itemName.isEmpty()) {
                    // Create an intent to pass the item details back to the InventoryActivity
                    Intent resultIntent = new Intent();

                    if (editMode) {
                        // include extra indicating edit mode and item details
                        resultIntent.putExtra("edit_mode", true);
                        resultIntent.putExtra("item_name", itemName);
                        resultIntent.putExtra("quantity", quantity);
                    } else {
                        // include extra indicating new item
                        resultIntent.putExtra("item_name", itemName);
                        resultIntent.putExtra("quantity", quantity);
                    }

                    // Set the result as OK and pass
                    setResult(RESULT_OK, resultIntent);

                    // Finish this activity to go back to the InventoryActivity
                    finish();
                } else {
                    showToast();
                }
            }
        });

        // Set onClick listener for the Back button
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish this activity to go back to the InventoryActivity
                finish();
            }
        });
    }

    // Display a toast message prompting to enter an item name
    private void showToast() {
        Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
    }
}
