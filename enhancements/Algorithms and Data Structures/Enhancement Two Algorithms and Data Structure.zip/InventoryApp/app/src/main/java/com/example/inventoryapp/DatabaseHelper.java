/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: SQLite database for creating tables, inserting, updating, deleting, and querying user data.
 */

package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants defining the structure of the user database table.
    private static final String DATABASE_NAME = "user_database";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_NAME + " TEXT," +
                    COLUMN_USERNAME + " TEXT UNIQUE," +
                    COLUMN_EMAIL + " TEXT UNIQUE," +
                    COLUMN_PASSWORD + " TEXT" +
                    ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create the users table when the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
    }

    // Handle database schema upgrades
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    // Public method to access the table name
    public static String getTableUsers() {
        return TABLE_USERS;
    }

    // Public methods to access column names
    public static String getColumnName() {
        return COLUMN_NAME;
    }

    // Public methods to access column username
    public static String getColumnUsername() {
        return COLUMN_USERNAME;
    }

    // Public methods to access column email
    public static String getColumnEmail() {
        return COLUMN_EMAIL;
    }

    // Public methods to access column password
    public static String getColumnPassword() {
        return COLUMN_PASSWORD;
    }

    // Method to retrieve user data based on username
    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {COLUMN_NAME, COLUMN_EMAIL, COLUMN_PASSWORD};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};
        return db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);
    }

    // Update user information in the database.
    public boolean updateUser(String oldUsername, String newUsername, String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        contentValues.put(COLUMN_USERNAME, newUsername);
        contentValues.put(COLUMN_EMAIL, email);
        contentValues.put(COLUMN_PASSWORD, password);
        int rowsAffected = db.update(TABLE_USERS, contentValues, COLUMN_USERNAME + " = ?", new String[]{oldUsername});
        return rowsAffected > 0;

    }

    // Delete a user from the database
    public boolean deleteUser(String username) {
        SQLiteDatabase db = getWritableDatabase();

        String whereClause = COLUMN_USERNAME + " = ?";
        String[] whereArgs = { username };

        int deletedRows = db.delete(TABLE_USERS, whereClause, whereArgs);

        db.close();

        return deletedRows > 0;
    }



    // Check login credentials
    public boolean checkLoginCredentials(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {COLUMN_USERNAME, COLUMN_PASSWORD};

        // Define the selection
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        // Query the database
        Cursor cursor = db.query(TABLE_USERS, projection, selection, selectionArgs, null, null, null);

        // Move cursor to the first row
        boolean credentialsMatch = cursor.moveToFirst();



        // Close the cursor and database
        cursor.close();
        db.close();

        return credentialsMatch;




    }
}
