/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Main interface for managing inventory items, CRUD operations, search functionality, SMS notifications, and navigation.
 */

package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.core.view.GravityCompat;
import androidx.appcompat.widget.SearchView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    // Variables
    private List<InventoryItem> itemsList;
    private List<InventoryItem> searchResultList = new ArrayList<>();
    private List<InventoryItem> originalItemsList;
    private ArrayAdapter<InventoryItem> adapter;
    private String loggedInUsername;
    private static final int ADD_ITEM_REQUEST_CODE = 1;
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private DBHelper dbHelper;
    private String userPhoneNumber;
    private SearchView searchView;

    // onCreate method called when activity is created
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize SearchView
        searchView = findViewById(R.id.searchView);

        // Get logged-in user's username from Intent
        Intent intent = getIntent();
        loggedInUsername = intent.getStringExtra("username");

        // Initialize database helper
        dbHelper = new DBHelper(this);

        // Retrieve all items for the logged-in user from the database
        itemsList = dbHelper.getAllItemsForUser(loggedInUsername);

        // Create a copy of the original items list for search functionality
        originalItemsList = new ArrayList<>(itemsList);

        // Use the custom layout for each item in the GridView
        adapter = new ArrayAdapter<InventoryItem>(this, R.layout.item_inventory, itemsList) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull android.view.ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_inventory, parent, false);
                }

                // Get the current item
                InventoryItem currentItem = getItem(position);

                // Set TextViews to display item details
                TextView itemNameTextView = convertView.findViewById(R.id.itemNameTextView);
                TextView quantityTextView = convertView.findViewById(R.id.quantityTextView);

                // Set values for TextViews
                if (currentItem != null) {
                    itemNameTextView.setText(currentItem.getItemName());
                    quantityTextView.setText("Quantity: " + currentItem.getQuantity());
                }

                // Delete button
                ImageButton buttonDelete = convertView.findViewById(R.id.buttonDelete);
                buttonDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String itemNameToDelete = currentItem.getItemName();

                        // Delete the item from the database
                        dbHelper.deleteItem(itemNameToDelete);

                        // Update itemsList after deletion
                        itemsList = dbHelper.getAllItemsForUser(loggedInUsername);
                        originalItemsList.clear(); // Clear the original items list
                        originalItemsList.addAll(itemsList); // Update original items list

                        // Update the search result list if it's not empty
                        if (!searchView.getQuery().toString().isEmpty()) {
                            updateSearchResults(searchView.getQuery().toString());
                        } else {
                            // Otherwise, update the adapter with the current items list
                            adapter.clear();
                            adapter.addAll(itemsList);
                            adapter.notifyDataSetChanged();
                        }

                        showToast("Item deleted: " + itemNameToDelete);
                    }
                });




                // Handle edit button
                ImageButton buttonEdit = convertView.findViewById(R.id.buttonEdit);
                buttonEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Handle edit button click
                        Intent editItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
                        editItemIntent.putExtra("edit_mode", true);
                        editItemIntent.putExtra("item_name", currentItem.getItemName());
                        editItemIntent.putExtra("quantity", currentItem.getQuantity());
                        startActivityForResult(editItemIntent, ADD_ITEM_REQUEST_CODE);
                    }
                });

                return convertView;
            }
        };

        // Set the adapter for GridView
        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(adapter);

        // Set OnClickListener for "Add Item" button
        Button addItemButton = findViewById(R.id.buttonAddItem);
        addItemButton.setOnClickListener(view -> {
            Intent addItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivityForResult(addItemIntent, ADD_ITEM_REQUEST_CODE);
        });

        // Set OnItemClickListener for GridView items
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InventoryItem clickedItem = adapter.getItem(position);
                Intent editItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
                editItemIntent.putExtra("edit_mode", true);
                editItemIntent.putExtra("item_name", clickedItem.getItemName());
                editItemIntent.putExtra("quantity", clickedItem.getQuantity());
                startActivityForResult(editItemIntent, ADD_ITEM_REQUEST_CODE);
            }
        });

        // Set OnClickListener for "Send SMS" button
        Button sendSmsButton = findViewById(R.id.buttonSendSms);
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        // Set welcome message for the logged-in user
        TextView textViewWelcome = findViewById(R.id.textViewInventory);
        textViewWelcome.setText("Welcome, " + loggedInUsername + "!");

        // Load user's phone number from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        userPhoneNumber = preferences.getString("user_phone_number_" + loggedInUsername, "");


        // Hamburger button and DrawerLayout
        ImageButton buttonMenu = findViewById(R.id.buttonMenu);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        buttonMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                    drawerLayout.closeDrawer(GravityCompat.END);
                } else {
                    drawerLayout.openDrawer(GravityCompat.END);
                }
            }
        });



        //Enhancment Two: Algorithms and Data Structures
        //Time complexity of the search functionality onQueryTextChange is O(n), where n is the number of items in the original list.
        // Set up search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Perform linear search
                List<InventoryItem> searchResultList = linearSearch(originalItemsList, newText);

                // Display or hide "Item not found" message based on search results
                if (searchResultList.isEmpty()) {
                    // Display a pop-up message indicating that the item was not found
                    showNotFoundPopup();
                } else {
                    // Update the adapter with search results
                    adapter.clear();
                    adapter.addAll(searchResultList);
                    adapter.notifyDataSetChanged();
                }
                return true;
            }
        });

        // Handle search text cleared
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // Restore the original item list
                if (!itemsList.equals(originalItemsList)) {
                    originalItemsList.clear();
                    originalItemsList.addAll(itemsList);
                }
                adapter.clear();
                adapter.addAll(originalItemsList);
                adapter.notifyDataSetChanged();
                return false;
            }
        });
    }

    // Linear search method
    // Time Complexity: O(n) - where n is the number of items in itemList
    // Iterates through each item in itemList to find items that match the query.
    private List<InventoryItem> linearSearch(List<InventoryItem> itemList, String query) {
        List<InventoryItem> searchResultList = new ArrayList<>();
        for (InventoryItem item : itemList) {
            if (item.getItemName().toLowerCase().contains(query.toLowerCase())) {
                searchResultList.add(item);
            }
        }
        return searchResultList;
    }



    // Method to handle logout
    public void logout(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to log out?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked Yes, proceed with logout
                Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finish the InventoryActivity
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked No, dismiss the dialog
                dialog.dismiss();
            }
        });
        builder.show();
    }

    // Method to open account settings
    public void openAccountSettings(MenuItem item) {
        // Pass the username to AccountActivity
        Intent intent = new Intent(this, AccountActivity.class);
        intent.putExtra("username", loggedInUsername);
        startActivity(intent);
    }

    // Method to display "Item not found" popup
    private void showNotFoundPopup() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View popupView = inflater.inflate(R.layout.popup_item_not_found, null);

        TextView textViewNotFound = popupView.findViewById(R.id.textViewNotFound);

        PopupWindow popupWindow = new PopupWindow(
                popupView,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        // Set an elevation value for popup window
        popupWindow.setElevation(10);

        // Show the popup window in the center of the screen
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

        // Dismiss the popup window after a delay
        new Handler().postDelayed(popupWindow::dismiss, 1000); // 1000 milliseconds (1 second)
    }


    // Method to update search results
    private void updateSearchResults(String query) {
        searchResultList.clear();
        for (InventoryItem item : originalItemsList) {
            if (item.getItemName().toLowerCase().contains(query.toLowerCase())) {
                searchResultList.add(item);
            }
        }
        adapter.clear();
        adapter.addAll(searchResultList);
        adapter.notifyDataSetChanged();
    }


    // Method to request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            showSmsConfirmationDialog();
        }
    }

    // Method to display SMS confirmation dialog
    private void showSmsConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Notifications");
        builder.setMessage("Do you want to receive low inventory notifications via SMS?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showPhoneNumberDialog();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveUserPreferences(userPhoneNumber, false); // Save preference when user clicks No
                showToast("SMS notifications disabled.");
            }
        });
        builder.show();
    }

    // Method to display phone number dialog
    private void showPhoneNumberDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_phone_number, null);
        builder.setView(dialogView);

        TextView textViewTitle = dialogView.findViewById(R.id.textViewTitle);
        EditText editTextPhoneNumber = dialogView.findViewById(R.id.editTextPhoneNumber);
        Button buttonOk = dialogView.findViewById(R.id.buttonOk);
        Button buttonCancel = dialogView.findViewById(R.id.buttonCancel);

        textViewTitle.setText("Enter 10 Digit Phone Number");

        // Pre-fill the phone number if available
        editTextPhoneNumber.setText(userPhoneNumber);

        AlertDialog dialog = builder.create();

        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userPhoneNumber = editTextPhoneNumber.getText().toString();

                // Save the user's phone number and preference to SharedPreferences
                saveUserPreferences(userPhoneNumber, true);

                // Check inventory and send notifications only if user wants to receive SMS
                if (shouldReceiveSms()) {
                    checkInventoryAndSendNotification();
                }

                dialog.dismiss();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserPreferences(userPhoneNumber, false); // Save preference when user clicks Cancel
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    // Method to save user preferences
    private void saveUserPreferences(String phoneNumber, boolean receiveSms) {
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        preferences.edit().putString("user_phone_number_" + loggedInUsername, phoneNumber).apply();
        preferences.edit().putBoolean("receive_sms_" + loggedInUsername, receiveSms).apply();
    }

    // Method to check if user should receive SMS notifications
    private boolean shouldReceiveSms() {
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        return preferences.getBoolean("receive_sms_" + loggedInUsername, false);
    }

    // Method to check inventory and send notifications
    private void checkInventoryAndSendNotification() {
        if (shouldReceiveSms() && !userPhoneNumber.isEmpty()) {
            List<InventoryItem> lowInventoryItems = new ArrayList<>();
            for (InventoryItem item : itemsList) {
                if (item.getQuantity() <= 0) {
                    lowInventoryItems.add(item);
                }
            }
            sendSms(userPhoneNumber, lowInventoryItems);
        }
    }

    // Method to send SMS notifications
    private void sendSms(String phoneNumber, List<InventoryItem> lowInventoryItems) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();

            // Check if there are items with low inventory
            if (lowInventoryItems != null && !lowInventoryItems.isEmpty()) {
                StringBuilder messageBuilder = new StringBuilder("Low inventory notification: Please check the following items with quantity 0:\n");
                for (InventoryItem item : lowInventoryItems) {
                    if (item.getQuantity() == 0) {
                        messageBuilder.append(item.getItemName()).append("\n");
                    }
                }

                // Send SMS with details of items with quantity 0
                String message = messageBuilder.toString();

                // Check if the phone number is not empty before sending SMS
                if (!phoneNumber.isEmpty()) {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    showToast("SMS sent successfully!");
                } else {
                    showToast("Phone number is empty. SMS not sent.");
                }
            } else {
                showToast("No items with quantity 0. SMS not sent.");
            }
        } else {
            showToast("SMS permission denied. Cannot send SMS.");
        }
    }


    // Method to handle permission request results
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showSmsConfirmationDialog();
            } else {
                showToast("SMS permission denied. Notifications won't be sent.");
            }
        }
    }

    // Method to handle activity results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            String itemName = data.getStringExtra("item_name");
            int quantity = data.getIntExtra("quantity", 0);

            if (data.getBooleanExtra("delete_item", false)) {
                dbHelper.deleteItem(itemName);
                showToast("Item deleted: " + itemName);
            } else {
                boolean itemExists = dbHelper.updateItem(itemName, quantity);
                if (!itemExists) {
                    dbHelper.addItem(loggedInUsername, itemName, quantity);
                    showToast("Item added: " + itemName);
                } else {
                    showToast("Item updated: " + itemName);
                }
            }

            // Refresh the items list and update the adapter
            itemsList = dbHelper.getAllItemsForUser(loggedInUsername);
            adapter.clear();
            adapter.addAll(itemsList);
            adapter.notifyDataSetChanged();

            // Update the originalItemsList to match the current state of itemsList
            originalItemsList.clear();
            originalItemsList.addAll(itemsList);

            // Update the search results if the search view is active
            if (!searchView.getQuery().toString().isEmpty()) {
                searchView.setQuery(searchView.getQuery(), true);
            }

            // Check inventory and send notifications
            checkInventoryAndSendNotification();
        }
    }

    // Method to display toast messages
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Method called when activity is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbHelper.close();
    }
}
