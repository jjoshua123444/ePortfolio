/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Database schema
 */

package com.example.inventoryapp;

public class InventoryContract {

    // Table name constant
    public static final String TABLE_NAME = "inventory";

    // Column names constants
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
}
