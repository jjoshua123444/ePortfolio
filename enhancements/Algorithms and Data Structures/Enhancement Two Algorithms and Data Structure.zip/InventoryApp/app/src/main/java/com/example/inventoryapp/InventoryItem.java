/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: A item in the inventory application.
 */

// InventoryItem.java
package com.example.inventoryapp;

public class InventoryItem {

    private long id; // Unique identifier for the item
    private String itemName; // Name of the item
    private int quantity; // Quantity of the item

    // Constructor with id
    public InventoryItem(long id, String itemName, int quantity) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Constructor without id
    public InventoryItem(String itemName, int quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Getter for id
    public long getId() {
        return id;
    }

    // Getter for item name
    public String getItemName() {
        return itemName;
    }

    // Getter for quantity
    public int getQuantity() {
        return quantity;
    }

    // Setter for quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Override toString method to represent item as a string
    @Override
    public String toString() {
        return itemName + " - Quantity: " + quantity;
    }
}
