/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Main interface for logging in and creating account.
 */

// MainActivity.java
package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername; // Username input field
    private EditText editTextPassword; // Password input field
    private DatabaseHelper databaseHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize input fields and buttons
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set click listener for login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get username and password from input fields
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    // Check login credentials in the database
                    boolean loginSuccessful = databaseHelper.checkLoginCredentials(username, password);

                    if (loginSuccessful) {
                        // Login successful
                        showToast("Login Successful");

                        // Pass the logged-in user's username to the InventoryActivity
                        Intent inventoryIntent = new Intent(MainActivity.this, InventoryActivity.class);
                        inventoryIntent.putExtra("username", username);
                        startActivity(inventoryIntent);


                        // Finish the MainActivity
                        finish();
                    } else {
                        // Login failed
                        showToast("Invalid username or password");
                    }
                } else {
                    showToast("Please enter both username and password");
                }
            }
        });


        // Set click listener for create account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the AccountCreationActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, AccountCreationActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to display toast messages
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
