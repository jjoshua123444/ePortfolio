/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Allows users to create a new account with firebase integration.
 */

package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.android.gms.tasks.OnCompleteListener;

public class AccountCreationActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextUsername;
    private EditText editTextEmail;
    private EditText editTextPassword;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize EditText fields
        editTextName = findViewById(R.id.editTextName);
        editTextUsername = findViewById(R.id.editTextNewUsername);
        editTextPassword = findViewById(R.id.editTextNewPassword);
        editTextEmail = findViewById(R.id.editTextEmail);

        // Initialize buttons
        Button signUpButton = findViewById(R.id.buttonSignUp);
        Button cancelButton = findViewById(R.id.buttonCancel);
        

        // Set onClick listener for the Sign Up button
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement sign-up logic
                String name = editTextName.getText().toString();
                String username = editTextUsername.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();

                if (!name.isEmpty() && !username.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                    // Create user with email and password
                    createUserWithEmailAndPassword(email, password);
                } else {
                    showToast("Please fill in all fields");
                }
            }
        });

        // Set onClick listener for the Cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Finish the activity to go back to the login page
            }
        });
    }

    //Enhancement three: Creating an account with firebase
    // Create user with email and password using Firebase Authentication
    private void createUserWithEmailAndPassword(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
                            // You may add additional actions here upon successful account creation
                            showToast("Account created successfully.");
                            // Proceed to other parts of the app or log in the user
                            startActivity(new Intent(AccountCreationActivity.this, InventoryActivity.class));
                            finish(); // Finish the activity after successful sign-up
                        } else {
                            // If account creation fails, display a message to the user.
                            showToast("Authentication failed: " + task.getException().getMessage());
                        }
                    }
                });
    }

    // Display a toast message
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
