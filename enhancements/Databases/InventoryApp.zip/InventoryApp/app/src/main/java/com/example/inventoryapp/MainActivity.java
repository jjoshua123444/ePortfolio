/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: Main interface for logging in and creating account.
 */

// MainActivity.java
package com.example.inventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername; // Username input field
    private EditText editTextPassword; // Password input field
    private DatabaseHelper databaseHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize input fields and buttons
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);
        Button forgotPasswordButton = findViewById(R.id.buttonForgotPassword); // New button for Forgot Password

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set click listener for login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Authenticate user using Firebase Authentication
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();
                login(username, password);
            }
        });

        // Set click listener for create account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the AccountCreationActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, AccountCreationActivity.class);
                startActivity(intent);
            }
        });

        // Set click listener for forgot password button
        forgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the PasswordResetActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, PasswordResetActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to authenticate user using Firebase Authentication
    private void login(String username, String password) {
        if (!username.isEmpty() && !password.isEmpty()) {
            FirebaseAuth.getInstance().signInWithEmailAndPassword(username, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Login successful
                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                if (user != null) {
                                    String loggedInUsername = user.getEmail(); // Use getEmail() to get the username
                                    showToast("Login Successful");

                                    // Pass the logged-in user's username to the InventoryActivity
                                    Intent inventoryIntent = new Intent(MainActivity.this, InventoryActivity.class);
                                    inventoryIntent.putExtra("username", loggedInUsername);
                                    startActivity(inventoryIntent);

                                    // Finish the MainActivity
                                    finish();
                                }
                            } else {
                                // Login failed
                                showToast("Invalid username or password");
                            }
                        }
                    });
        } else {
            showToast("Please enter both username and password");
        }
    }

    // Method to display toast messages
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
