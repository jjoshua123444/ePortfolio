/*
 * Joshua James
 * Institution: Southern New Hampshire University
 * Date: March 28, 2024
 * Version: 1.0
 * Description: My initial SHA-256 algorithm before using firebase. This is not being used at the moment.
 */


//package com.example.inventoryapp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

//public class PasswordHash {

    // Hash the password using SHA-256
    //public static String hashPassword(String password) {
      //  try {
            //MessageDigest digest = MessageDigest.getInstance("SHA-256");
            //byte[] hash = digest.digest(password.getBytes());
            //StringBuilder hexString = new StringBuilder();

            //for (byte b : hash) {
                //String hex = Integer.toHexString(0xff & b);
                //if (hex.length() == 1) hexString.append('0');
                //hexString.append(hex);
            //}

            //return hexString.toString();
        //} catch (NoSuchAlgorithmException e) {
            //e.printStackTrace();
            //return null; // Return null if hashing fails
        //}
    //}
//}
