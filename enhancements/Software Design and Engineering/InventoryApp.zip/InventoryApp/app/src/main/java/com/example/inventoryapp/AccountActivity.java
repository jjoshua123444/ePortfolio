package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class AccountActivity extends AppCompatActivity {

    // UI components for managing user account information
    private TextInputEditText editTextName;
    private TextInputEditText editTextUsername;
    private TextInputEditText editTextEmail;
    private TextInputEditText editTextPassword;
    private Button buttonEdit;
    private Button buttonSave;
    private Button buttonDelete;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the activity_account layout
        setContentView(R.layout.activity_account);

        // Initialize EditText fields
        editTextName = findViewById(R.id.editTextNameUpdate);
        editTextUsername = findViewById(R.id.editTextUsernameUpdate);
        editTextEmail = findViewById(R.id.editTextEmailUpdate);
        editTextPassword = findViewById(R.id.editTextPasswordUpdate);

        // Initialize Buttons
        buttonEdit = findViewById(R.id.buttonEdit);
        buttonSave = findViewById(R.id.buttonSave);
        buttonDelete = findViewById(R.id.buttonDeleteAccount);

        // Hide Save button initially
        buttonSave.setVisibility(View.GONE);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Retrieve the username passed from the previous activity
        String username = getIntent().getStringExtra("username");

        // Populate user information using the retrieved username
        populateUserInfo(username);

        // Set onClick listener for the Edit button
        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enableEditTextFields();
                toggleEditSaveButtonsVisibility();
            }
        });

        // Set onClick listener for the save button
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserInfo();
                disableEditTextFields();
                toggleEditSaveButtonsVisibility();
            }
        });

        // Set onClick listener for the cancel button
        Button cancelButton = findViewById(R.id.buttonCancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the inventory screen
                onBackPressed(); // This will mimic the back button press
            }
        });

        // Set onClick listener for the Delete Account button
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog();
            }
        });
    }



    // Enable EditText fields
    private void enableEditTextFields() {
        editTextName.setEnabled(true);
        editTextUsername.setEnabled(true);
        editTextEmail.setEnabled(true);
        editTextPassword.setEnabled(true);
    }

    // Disable EditText fields
    private void disableEditTextFields() {
        editTextName.setEnabled(false);
        editTextUsername.setEnabled(false);
        editTextEmail.setEnabled(false);
        editTextPassword.setEnabled(false);
    }

    // Toggle visibility of Edit and Save buttons
    private void toggleEditSaveButtonsVisibility() {
        if (buttonEdit.getVisibility() == View.VISIBLE) {
            buttonEdit.setVisibility(View.GONE);
            buttonSave.setVisibility(View.VISIBLE);
        } else {
            buttonEdit.setVisibility(View.VISIBLE);
            buttonSave.setVisibility(View.GONE);
        }
    }

    private void populateUserInfo(String username) {
        // Retrieve user information from the database
        Cursor cursor = databaseHelper.getUserByUsername(username);

        // Check if the cursor contains data
        if (cursor != null && cursor.moveToFirst()) {
            // Retrieve column indexes for the required columns
            int nameIndex = cursor.getColumnIndex(DatabaseHelper.getColumnName());
            int emailIndex = cursor.getColumnIndex(DatabaseHelper.getColumnEmail());
            int passwordIndex = cursor.getColumnIndex(DatabaseHelper.getColumnPassword());

            // Check if the column indexes are valid (-1 indicates column not found)
            if (nameIndex != -1 && emailIndex != -1 && passwordIndex != -1) {
                // Retrieve user information from the cursor
                String name = cursor.getString(nameIndex);
                String email = cursor.getString(emailIndex);
                String password = cursor.getString(passwordIndex);

                // Set the EditText fields with the retrieved user information
                editTextName.setText(name);
                editTextUsername.setText(username); // Assuming username doesn't change
                editTextEmail.setText(email);
                editTextPassword.setText(password);
            }
        }
        // Close the cursor
        if (cursor != null) {
            cursor.close();
        }
    }

    private void updateUserInfo() {
        // Retrieve old username from intent extras
        String oldUsername = getIntent().getStringExtra("username");

        // Get new user information from EditText fields
        String name = editTextName.getText().toString().trim();
        String newUsername = editTextUsername.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim(); // Get the new email
        String password = editTextPassword.getText().toString().trim();

        // Update user information in the database
        boolean updated = databaseHelper.updateUser(oldUsername, newUsername, name, email, password);

        // Display toast message based on the success or failure of the update operation
        if (updated) {
            Toast.makeText(AccountActivity.this, "User information updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AccountActivity.this, "Failed to update user information", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder instance
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Set the title and message of the dialog
        builder.setTitle("Delete Account");
        builder.setMessage("Are you sure you want to delete your account?");

        // Set the positive button action (Yes)
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Set the positive button action (Yes)
                deleteAccount();
            }
        });
        // Set the negative button action (No)
        builder.setNegativeButton("No", null);

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void deleteAccount() {
        // Get the username of the account to be deleted
        String username = getIntent().getStringExtra("username");

        // Delete the account from the database
        boolean deleted = databaseHelper.deleteUser(username);

        if (deleted) {
            // Account deleted successfully, navigate back to the login page
            Toast.makeText(AccountActivity.this, "Account deleted successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(AccountActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close the current activity to prevent going back to it from the login page
        } else {
            Toast.makeText(AccountActivity.this, "Failed to delete account", Toast.LENGTH_SHORT).show();
        }
    }
}
