package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class AccountCreationActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextUsername;

    private EditText editTextEmail;

    private EditText editTextPassword;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        editTextName = findViewById(R.id.editTextName);
        editTextUsername = findViewById(R.id.editTextNewUsername);
        editTextPassword = findViewById(R.id.editTextNewPassword);
        editTextEmail = findViewById(R.id.editTextEmail);

        Button signUpButton = findViewById(R.id.buttonSignUp);
        Button cancelButton = findViewById(R.id.buttonCancel);

        databaseHelper = new DatabaseHelper(this);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement sign-up logic
                String name = editTextName.getText().toString();
                String username = editTextUsername.getText().toString();
                String email = editTextEmail.getText().toString();
                String password = editTextPassword.getText().toString();

                if (!name.isEmpty() && !username.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                    // Insert user data into the database
                    long newRowId = insertUserData(name, username, email, password);

                    if (newRowId != -1) {
                        showToast("Account Created Successfully");
                        // Start InventoryActivity and pass the username
                        Intent inventoryIntent = new Intent(AccountCreationActivity.this, InventoryActivity.class);
                        inventoryIntent.putExtra("username", username);
                        startActivity(inventoryIntent);

                        finish(); // Finish the activity after successful sign-up
                    } else {
                        showToast("Username already exists. Choose a different one.");
                    }
                } else {
                    showToast("Please fill in all fields");
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Finish the activity to go back to the login page
            }
        });
    }

    private long insertUserData(String name, String username, String email, String password) {
        SQLiteDatabase db = null;
        long newRowId = -1;

        try {
            db = databaseHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.getColumnName(), name);
            values.put(DatabaseHelper.getColumnUsername(), username);
            values.put(DatabaseHelper.getColumnEmail(), email);
            values.put(DatabaseHelper.getColumnPassword(), password);

            // Insert data into the database
            newRowId = db.insert(DatabaseHelper.getTableUsers(), null, values);

            // Log success message
            Log.d("DatabaseHelper", "Data inserted successfully. Row ID: " + newRowId);
        } catch (Exception e) {
            // Log error message
            Log.e("DatabaseHelper", "Error inserting data: " + e.getMessage());
        } finally {
            // Close the database
            if (db != null && db.isOpen()) {
                db.close();
            }
        }

        return newRowId;
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
