package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.core.view.GravityCompat;



import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private List<InventoryItem> itemsList;
    private ArrayAdapter<InventoryItem> adapter;
    private String loggedInUsername;
    private static final int ADD_ITEM_REQUEST_CODE = 1;
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    private DBHelper dbHelper;
    private String userPhoneNumber;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        Intent intent = getIntent();
        loggedInUsername = intent.getStringExtra("username");

        dbHelper = new DBHelper(this);

        itemsList = dbHelper.getAllItemsForUser(loggedInUsername);

        // Use the custom layout for each item in the GridView
        adapter = new ArrayAdapter<InventoryItem>(this, R.layout.item_inventory, itemsList) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull android.view.ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_inventory, parent, false);
                }

                // Get the current item
                InventoryItem currentItem = getItem(position);

                // Set TextViews to display item details
                TextView itemNameTextView = convertView.findViewById(R.id.itemNameTextView);
                TextView quantityTextView = convertView.findViewById(R.id.quantityTextView);

                // Set values for TextViews
                if (currentItem != null) {
                    itemNameTextView.setText(currentItem.getItemName());
                    quantityTextView.setText("Quantity: " + currentItem.getQuantity());
                }

                // delete button
                ImageButton buttonDelete = convertView.findViewById(R.id.buttonDelete);
                buttonDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String itemNameToDelete = currentItem.getItemName();

                        // Delete the item from the database
                        dbHelper.deleteItem(itemNameToDelete);

                        // Update itemsList after deletion
                        itemsList = dbHelper.getAllItemsForUser(loggedInUsername);
                        adapter.clear();
                        adapter.addAll(itemsList);
                        adapter.notifyDataSetChanged();

                        showToast("Item deleted: " + itemNameToDelete);
                    }
                });


                // Handle edit button
                ImageButton buttonEdit = convertView.findViewById(R.id.buttonEdit);
                buttonEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Handle edit button click
                        Intent editItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
                        editItemIntent.putExtra("edit_mode", true);
                        editItemIntent.putExtra("item_name", currentItem.getItemName());
                        editItemIntent.putExtra("quantity", currentItem.getQuantity());
                        startActivityForResult(editItemIntent, ADD_ITEM_REQUEST_CODE);
                    }
                });

                return convertView;
            }
        };

        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(adapter);

        Button addItemButton = findViewById(R.id.buttonAddItem);
        addItemButton.setOnClickListener(view -> {
            Intent addItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivityForResult(addItemIntent, ADD_ITEM_REQUEST_CODE);
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InventoryItem clickedItem = adapter.getItem(position);
                Intent editItemIntent = new Intent(InventoryActivity.this, AddItemActivity.class);
                editItemIntent.putExtra("edit_mode", true);
                editItemIntent.putExtra("item_name", clickedItem.getItemName());
                editItemIntent.putExtra("quantity", clickedItem.getQuantity());
                startActivityForResult(editItemIntent, ADD_ITEM_REQUEST_CODE);
            }
        });

        Button sendSmsButton = findViewById(R.id.buttonSendSms);
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        TextView textViewWelcome = findViewById(R.id.textViewInventory);
        textViewWelcome.setText("Welcome, " + loggedInUsername + "!");

        // Load user's phone number from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        userPhoneNumber = preferences.getString("user_phone_number_" + loggedInUsername, "");


        // Hamburger button
        ImageButton buttonMenu = findViewById(R.id.buttonMenu);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        buttonMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                    drawerLayout.closeDrawer(GravityCompat.END);
                } else {
                    drawerLayout.openDrawer(GravityCompat.END);
                }
            }
        });
    }



    //log out
    public void logout(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to log out?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked Yes, proceed with logout
                Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finish the InventoryActivity to prevent returning to it with back button
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked No, dismiss the dialog
                dialog.dismiss();
            }
        });
        builder.show();
    }

    //account settings
    public void openAccountSettings(MenuItem item) {
        // Pass the username to AccountActivity
        Intent intent = new Intent(this, AccountActivity.class);
        intent.putExtra("username", loggedInUsername);
        startActivity(intent);
    }




    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            showSmsConfirmationDialog();
        }
    }

    private void showSmsConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Notifications");
        builder.setMessage("Do you want to receive low inventory notifications via SMS?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showPhoneNumberDialog();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveUserPreferences(userPhoneNumber, false); // Save preference when user clicks No
                showToast("SMS notifications disabled.");
            }
        });
        builder.show();
    }

    private void showPhoneNumberDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_phone_number, null);
        builder.setView(dialogView);

        TextView textViewTitle = dialogView.findViewById(R.id.textViewTitle);
        EditText editTextPhoneNumber = dialogView.findViewById(R.id.editTextPhoneNumber);
        Button buttonOk = dialogView.findViewById(R.id.buttonOk);
        Button buttonCancel = dialogView.findViewById(R.id.buttonCancel);

        textViewTitle.setText("Enter 10 Digit Phone Number");

        // Pre-fill the phone number if available
        editTextPhoneNumber.setText(userPhoneNumber);

        AlertDialog dialog = builder.create();

        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userPhoneNumber = editTextPhoneNumber.getText().toString();

                // Save the user's phone number and preference to SharedPreferences
                saveUserPreferences(userPhoneNumber, true);

                // Check inventory and send notifications only if user wants to receive SMS
                if (shouldReceiveSms()) {
                    checkInventoryAndSendNotification();
                }

                dialog.dismiss();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserPreferences(userPhoneNumber, false); // Save preference when user clicks Cancel
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void saveUserPreferences(String phoneNumber, boolean receiveSms) {
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        preferences.edit().putString("user_phone_number_" + loggedInUsername, phoneNumber).apply();
        preferences.edit().putBoolean("receive_sms_" + loggedInUsername, receiveSms).apply();
    }

    private boolean shouldReceiveSms() {
        SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        return preferences.getBoolean("receive_sms_" + loggedInUsername, false);
    }

    private void checkInventoryAndSendNotification() {
        if (shouldReceiveSms() && !userPhoneNumber.isEmpty()) {
            List<InventoryItem> lowInventoryItems = new ArrayList<>();
            for (InventoryItem item : itemsList) {
                if (item.getQuantity() <= 0) {
                    lowInventoryItems.add(item);
                }
            }
            sendSms(userPhoneNumber, lowInventoryItems);
        }
    }

    private void sendSms(String phoneNumber, List<InventoryItem> lowInventoryItems) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();

            // Check if there are items with low inventory
            if (lowInventoryItems != null && !lowInventoryItems.isEmpty()) {
                StringBuilder messageBuilder = new StringBuilder("Low inventory notification: Please check the following items with quantity 0:\n");
                for (InventoryItem item : lowInventoryItems) {
                    if (item.getQuantity() == 0) {
                        messageBuilder.append(item.getItemName()).append("\n");
                    }
                }

                // Send SMS with details of items with quantity 0
                String message = messageBuilder.toString();

                // Check if the phone number is not empty before sending SMS
                if (!phoneNumber.isEmpty()) {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    showToast("SMS sent successfully!");
                } else {
                    showToast("Phone number is empty. SMS not sent.");
                }
            } else {
                showToast("No items with quantity 0. SMS not sent.");
            }
        } else {
            showToast("SMS permission denied. Cannot send SMS.");
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showSmsConfirmationDialog();
            } else {
                showToast("SMS permission denied. Notifications won't be sent.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            String itemName = data.getStringExtra("item_name");
            int quantity = data.getIntExtra("quantity", 0);

            if (data.getBooleanExtra("delete_item", false)) {
                dbHelper.deleteItem(itemName);

                itemsList = dbHelper.getAllItemsForUser(loggedInUsername);
                adapter.clear();
                adapter.addAll(itemsList);
                adapter.notifyDataSetChanged();

                showToast("Item deleted: " + itemName);
            } else {
                boolean itemExists = dbHelper.updateItem(itemName, quantity);

                if (!itemExists) {
                    dbHelper.addItem(loggedInUsername, itemName, quantity);
                }

                itemsList = dbHelper.getAllItemsForUser(loggedInUsername);
                adapter.clear();
                adapter.addAll(itemsList);
                adapter.notifyDataSetChanged();

                showToast(itemExists ? "Item updated: " + itemName : "Item added: " + itemName);
            }

            checkInventoryAndSendNotification();
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbHelper.close();
    }
}
