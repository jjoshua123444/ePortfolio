// InventoryContract.java
package com.example.inventoryapp;

public class InventoryContract {
    public static final String TABLE_NAME = "inventory";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
}
