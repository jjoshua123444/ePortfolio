// InventoryItem.java
package com.example.inventoryapp;

public class InventoryItem {

    private long id;
    private String itemName;
    private int quantity;

    // Updated constructor to include id
    public InventoryItem(long id, String itemName, int quantity) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Constructor without id
    public InventoryItem(String itemName, int quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Getter for id
    public long getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    // Add a setter method for updating the quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return itemName + " - Quantity: " + quantity;
    }
}
