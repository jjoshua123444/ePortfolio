// DBHelper.java
package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + InventoryContract.TABLE_NAME + " (" +
                InventoryContract.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryContract.COLUMN_USER_ID + " TEXT, " +
                InventoryContract.COLUMN_ITEM_NAME + " TEXT, " +
                InventoryContract.COLUMN_QUANTITY + " INTEGER)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + InventoryContract.TABLE_NAME);
        onCreate(db);
    }

    public long addItem(String userId, String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryContract.COLUMN_USER_ID, userId);
        values.put(InventoryContract.COLUMN_ITEM_NAME, itemName);
        values.put(InventoryContract.COLUMN_QUANTITY, quantity);

        long newRowId = db.insert(InventoryContract.TABLE_NAME, null, values);

        db.close();
        return newRowId;
    }

    public List<InventoryItem> getAllItemsForUser(String userId) {
        List<InventoryItem> itemsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                InventoryContract.COLUMN_ID,
                InventoryContract.COLUMN_USER_ID,
                InventoryContract.COLUMN_ITEM_NAME,
                InventoryContract.COLUMN_QUANTITY
        };

        String selection = InventoryContract.COLUMN_USER_ID + " = ?";
        String[] selectionArgs = { userId };

        Cursor cursor = db.query(
                InventoryContract.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long itemID = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryContract.COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryContract.COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryContract.COLUMN_QUANTITY));

            InventoryItem item = new InventoryItem(itemID, itemName, quantity);
            itemsList.add(item);
        }

        cursor.close();
        db.close();

        return itemsList;
    }


    public boolean updateItem(String itemName, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryContract.COLUMN_QUANTITY, newQuantity);

        String selection = InventoryContract.COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = { itemName };

        int rowsUpdated = db.update(
                InventoryContract.TABLE_NAME,
                values,
                selection,
                selectionArgs
        );

        db.close();

        return rowsUpdated > 0;
    }

    public int deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        String selection = InventoryContract.COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = { itemName };

        int rowsDeleted = db.delete(
                InventoryContract.TABLE_NAME,
                selection,
                selectionArgs
        );

        db.close();
        return rowsDeleted;
    }
}
