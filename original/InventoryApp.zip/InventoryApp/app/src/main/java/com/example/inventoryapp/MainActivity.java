// MainActivity.java
package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement login logic
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    // Check login credentials in the database
                    boolean loginSuccessful = databaseHelper.checkLoginCredentials(username, password);

                    if (loginSuccessful) {
                        // Login successful, start the InventoryActivity
                        showToast("Login Successful");

                        Intent inventoryIntent = new Intent(MainActivity.this, InventoryActivity.class);
                        inventoryIntent.putExtra("username", username);
                        startActivity(inventoryIntent);

                        // Finish the MainActivity
                        finish();
                    } else {
                        // Login failed
                        showToast("Invalid username or password");
                    }
                } else {
                    showToast("Please enter both username and password");
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the AccountCreationActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, AccountCreationActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
